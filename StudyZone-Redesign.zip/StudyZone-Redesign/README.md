# StudyZone

Modernisierte Lernplattform auf Basis von React und Vite.

## Starten

```bash
npm install
npm run dev
```

## Produktionsbuild

```bash
npm run build
npm run preview
```

## Enthaltene Verbesserungen

- Überarbeitetes, konsistentes UI mit Dark Mode und responsivem Layout
- Sanfte Seiten-, Karten-, Fortschritts- und Quizanimationen
- Fortsetzen-Karte für die zuletzt geöffnete Lektion
- Suchzustände mit verständlicher Meldung, wenn keine Treffer vorhanden sind
- Tastaturbedienung: Escape schließt Profilfenster und mobiles Menü
- Barriereärmere Fokuszustände und Dialog-Kennzeichnung
- XP werden für eine bereits abgeschlossene Lektion nicht erneut vergeben
- Lernfortschritt und Einstellungen werden lokal im Browser gespeichert

Hinweis: Der Produktionsbuild konnte in der aktuellen Umgebung nicht ausgeführt werden, weil die Installation der npm-Abhängigkeiten in einen Timeout lief. Bitte nach `npm install` lokal mit `npm run build` prüfen.
